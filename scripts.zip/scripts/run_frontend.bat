@echo off
title CFO Frontend (Next.js)
color 0E
cd /d "%~dp0..\frontend"
echo [*] Starting Next.js Frontend on http://localhost:3000 ...
npm run dev
pause
