import os
import sys
import pandas as pd
from datetime import datetime
from pathlib import Path

# Add project root to path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from backend.app.db.database import engine, Base, SessionLocal
from backend.app.db.models import (
    User, Region, Segment, Sale, Order, Dispatch,
    VendorPayable, CashTransaction, Production
)

def load_data():
    print("[1/4] Initializing Database Schema...")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    try:
        print("[2/4] Loading Master Records...")
        for r in ["North", "South", "East", "West"]:
            db.add(Region(name=r))
        for s in ["Government", "Enterprise", "Retail", "SME"]:
            db.add(Segment(name=s))
            
        cfo_user = User(
            name="CFO Aditya Verma",
            email="cfo@company.com",
            password_hash="$2b$12$e7kH6mG9Xl6D1z0Q0Q0Q0uKqJ9y3v5w6x7y8z9a0b1c2d3e4f5g6h",
            role="CFO"
        )
        db.add(cfo_user)
        db.commit()
        
        print("[3/4] Ingesting Cleaned Kaggle DataCo Dataset...")
        processed_path = "data/processed/processed_supply_chain.csv"
        df = pd.read_csv(processed_path)
        
        sales_to_insert = []
        orders_to_insert = []
        
        for idx, row in df.iterrows():
            o_date = datetime.strptime(str(row["order_date"])[:10], "%Y-%m-%d").date()
            s_date = datetime.strptime(str(row["shipping_date"])[:10], "%Y-%m-%d").date() if pd.notnull(row.get("shipping_date")) else o_date
            
            # Sale
            sales_to_insert.append(Sale(
                date=o_date,
                customer_name=str(row.get("customer", "Corporate Client")),
                region=str(row.get("region", "North")),
                segment=str(row.get("segment", "Enterprise")),
                product=str(row.get("product", "Industrial Supply"))[:100],
                quantity=int(row.get("quantity", 1)),
                revenue=float(row.get("revenue", 0.0)),
                cost=float(row.get("cost", 0.0)),
                profit=float(row.get("profit", 0.0))
            ))
            
            # Order
            stat = str(row.get("order_status", "COMPLETE"))
            norm_status = "Completed" if stat in ["COMPLETE", "CLOSED"] else ("Pending" if "PENDING" in stat else "In Progress")
            
            order_obj = Order(
                order_date=o_date,
                customer_name=str(row.get("customer", "Corporate Client")),
                region=str(row.get("region", "North")),
                product=str(row.get("product", "Industrial Supply"))[:100],
                quantity=int(row.get("quantity", 1)),
                order_value=float(row.get("revenue", 0.0)),
                status=norm_status,
                expected_delivery_date=s_date
            )
            orders_to_insert.append(order_obj)
            
        db.bulk_save_objects(sales_to_insert)
        db.commit()
        print(f"Loaded {len(sales_to_insert)} sales records from Kaggle dataset.")
        
        # Load orders (first 3000 for responsive order-dispatch operational tracking)
        db.bulk_save_objects(orders_to_insert[:3000])
        db.commit()
        
        # Generate dispatches linked to orders
        created_orders = db.query(Order).all()
        dispatches_to_insert = []
        for o in created_orders:
            d_status = "Dispatched" if o.status == "Completed" else ("Partially Dispatched" if o.status == "In Progress" else "Pending")
            disp_qty = o.quantity if o.status == "Completed" else (max(1, o.quantity - 1) if o.status == "In Progress" else 0)
            dispatches_to_insert.append(Dispatch(
                order_id=o.id,
                dispatch_date=o.expected_delivery_date,
                quantity=disp_qty,
                status=d_status
            ))
        db.bulk_save_objects(dispatches_to_insert)
        db.commit()
        print(f"Loaded {len(created_orders)} orders and {len(dispatches_to_insert)} dispatches.")
        
        print("[4/4] Ingesting Auxiliary CFO Datasets (Payables, Cash Flow, Production)...")
        # Payables
        payables_df = pd.read_csv("data/processed/auxiliary_payables.csv")
        payables_objs = [
            VendorPayable(
                vendor=row["vendor"],
                invoice_number=row["invoice_number"],
                invoice_date=datetime.strptime(str(row["invoice_date"]), "%Y-%m-%d").date(),
                due_date=datetime.strptime(str(row["due_date"]), "%Y-%m-%d").date(),
                invoice_amount=float(row["invoice_amount"]),
                paid_amount=float(row["paid_amount"]),
                outstanding_amount=float(row["outstanding_amount"]),
                status=row["status"]
            )
            for _, row in payables_df.iterrows()
        ]
        db.bulk_save_objects(payables_objs)
        
        # Cash Flow
        cash_df = pd.read_csv("data/processed/auxiliary_cash_flow.csv")
        cash_objs = [
            CashTransaction(
                date=datetime.strptime(str(row["date"]), "%Y-%m-%d").date(),
                transaction_type=row["transaction_type"],
                category=row["category"],
                description=str(row["description"]),
                amount=float(row["amount"])
            )
            for _, row in cash_df.iterrows()
        ]
        db.bulk_save_objects(cash_objs)
        
        # Production
        prod_df = pd.read_csv("data/processed/auxiliary_production.csv")
        prod_objs = [
            Production(
                date=datetime.strptime(str(row["date"]), "%Y-%m-%d").date(),
                plant=row["plant"],
                product=row["product"],
                capacity=float(row["capacity"]),
                planned_quantity=float(row["planned_quantity"]),
                actual_quantity=float(row["actual_quantity"]),
                utilization_percentage=float(row["utilization_percentage"])
            )
            for _, row in prod_df.iterrows()
        ]
        db.bulk_save_objects(prod_objs)
        
        db.commit()
        print(f"Loaded {len(payables_objs)} payables, {len(cash_objs)} cash transactions, {len(prod_objs)} production records.")
        print("Database loaded and verified with Kaggle data successfully!")
        
    except Exception as e:
        db.rollback()
        print(f"Error loading database: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    load_data()
