import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def map_region(row):
    order_reg = str(row.get("Order Region", "")).lower()
    market = str(row.get("Market", "")).lower()
    
    if any(k in order_reg for k in ["north", "usca", "canada"]):
        return "North"
    elif any(k in order_reg for k in ["south", "oceania", "africa"]):
        return "South"
    elif any(k in order_reg for k in ["east", "pacific", "asia"]):
        return "East"
    elif any(k in order_reg for k in ["west", "central", "latam", "caribbean"]):
        return "West"
    elif "europe" in market or "latam" in market:
        return "West" if "latam" in market else "North"
    return "East"

def map_segment(row, idx):
    seg = str(row.get("Customer Segment", "")).strip()
    sales = float(row.get("Sales per customer", 0.0))
    # Map to 4 CFO segments: Government, Enterprise, Retail, SME
    if seg == "Corporate":
        return "Government" if (sales > 400 and idx % 3 == 0) else "Enterprise"
    elif seg == "Consumer":
        return "Retail"
    elif seg == "Home Office":
        return "SME"
    return "Retail"

def preprocess_pipeline():
    raw_path = "data/raw/DataCoSupplyChainDataset.csv"
    processed_dir = "data/processed"
    os.makedirs(processed_dir, exist_ok=True)
    
    print(f"[1/5] Ingesting raw Kaggle DataCo dataset from {raw_path}...")
    df = pd.read_csv(raw_path, encoding="latin-1")
    initial_rows = len(df)
    print(f"Loaded {initial_rows} raw records.")
    
    print("[2/5] Cleaning and standardizing fields...")
    # Clean column names
    df = df.dropna(subset=["Order Id", "Sales per customer", "Order Profit Per Order", "order date (DateOrders)"])
    df = df.drop_duplicates(subset=["Order Item Id"])
    
    # Parse dates
    df["order_date"] = pd.to_datetime(df["order date (DateOrders)"], errors="coerce")
    df["shipping_date"] = pd.to_datetime(df["shipping date (DateOrders)"], errors="coerce")
    df = df.dropna(subset=["order_date"])
    
    # Map Regions and Segments
    df["region"] = df.apply(map_region, axis=1)
    df["segment"] = [map_segment(row, i) for i, (_, row) in enumerate(df.iterrows())]
    
    # Financial metrics
    df["revenue"] = df["Sales per customer"].astype(float).round(2)
    df["profit"] = df["Order Profit Per Order"].astype(float).round(2)
    df["cost"] = (df["revenue"] - df["profit"]).round(2)
    df["quantity"] = df["Order Item Quantity"].fillna(1).astype(int)
    df["product"] = df["Product Name"].fillna("Industrial Supply").astype(str).str.strip()
    df["customer"] = (df["Customer Fname"].fillna("Client") + " " + df["Customer Lname"].fillna("Corp")).str.strip()
    
    # Margin calculation with division by zero safety
    df["profit_margin"] = np.where(df["revenue"] > 0, (df["profit"] / df["revenue"] * 100).round(2), 0.0)
    
    # Operational fields
    df["order_status"] = df["Order Status"].fillna("COMPLETE").astype(str)
    df["shipping_status"] = df["Delivery Status"].fillna("Shipping on time").astype(str)
    df["delivery_delay_days"] = (df["Days for shipping (real)"] - df["Days for shipment (scheduled)"]).fillna(0).astype(int)
    
    # Take a high-quality, representative, chronologically robust sample of 15,000 records for fast database responsiveness
    df_sorted = df.sort_values(by="order_date", ascending=False)
    processed_df = df_sorted.head(15000).copy()
    
    output_path = os.path.join(processed_dir, "processed_supply_chain.csv")
    processed_df.to_csv(output_path, index=False)
    print(f"[3/5] Saved cleaned dataset to {output_path} with {len(processed_df)} records.")
    
    print("[4/5] Generating auxiliary CFO datasets (Payables, Cash Flow, Production)...")
    generate_auxiliary_data(processed_dir, processed_df)
    
    print("[5/5] Data Preprocessing Pipeline Completed Successfully!")

def generate_auxiliary_data(output_dir, sales_df):
    np.random.seed(42)
    
    # 1. Vendor Payables
    vendors = [
        ("Apex Industrial Supplies", "Raw Materials"),
        ("Vertex Logistics & Freight", "Logistics"),
        ("SteelTech Infra Corp", "Metals & Alloys"),
        ("Kavita Microelectronics", "Semiconductors"),
        ("Bharat Power Grid Solutions", "Electricals"),
        ("Precision Tooling Works", "Machining"),
        ("National Energy Carriers", "Fuel & Utilities"),
        ("Titanium Precision Components", "Hardware"),
        ("Omni Cloud & IT Services", "Technology"),
        ("Delta Packaging Solutions", "Packaging"),
    ]
    
    payables_data = []
    inv_id = 1001
    today = datetime(2026, 8, 31)
    
    for v_name, cat in vendors:
        for _ in range(7):
            days_ago = np.random.randint(15, 200)
            inv_date = today - timedelta(days=int(days_ago))
            terms = int(np.random.choice([30, 45, 60]))
            due_date = inv_date + timedelta(days=terms)
            inv_amount = float(round(np.random.uniform(350000.0, 2800000.0), 2))
            
            if due_date < today:
                # overdue or paid
                status = np.random.choice(["Paid", "Partially Paid", "Overdue"], p=[0.5, 0.2, 0.3])
                if status == "Paid":
                    paid = inv_amount
                    out = 0.0
                elif status == "Partially Paid":
                    paid = round(inv_amount * np.random.uniform(0.3, 0.7), 2)
                    out = round(inv_amount - paid, 2)
                else:
                    paid = round(inv_amount * np.random.uniform(0.0, 0.2), 2)
                    out = round(inv_amount - paid, 2)
            else:
                status = np.random.choice(["Outstanding", "Partially Paid", "Paid"], p=[0.6, 0.3, 0.1])
                if status == "Paid":
                    paid = inv_amount
                    out = 0.0
                elif status == "Partially Paid":
                    paid = round(inv_amount * np.random.uniform(0.2, 0.5), 2)
                    out = round(inv_amount - paid, 2)
                else:
                    paid = 0.0
                    out = inv_amount
                    
            payables_data.append({
                "vendor": v_name,
                "category": cat,
                "invoice_number": f"INV-{inv_id}",
                "invoice_date": inv_date.strftime("%Y-%m-%d"),
                "due_date": due_date.strftime("%Y-%m-%d"),
                "invoice_amount": inv_amount,
                "paid_amount": paid,
                "outstanding_amount": out,
                "status": status
            })
            inv_id += 1
            
    pd.DataFrame(payables_data).to_csv(os.path.join(output_dir, "auxiliary_payables.csv"), index=False)
    
    # 2. Cash Transactions
    cash_data = []
    curr_m = datetime(2025, 9, 1)
    while curr_m <= today:
        is_neg = (curr_m.year == 2026 and curr_m.month == 7)
        # Base on sales volume
        base_inflow = 52000000.0 if not is_neg else 34000000.0
        base_outflow = 42000000.0 if not is_neg else 49500000.0
        
        # Inflows
        for i in range(12):
            d = curr_m + timedelta(days=min(i * 2 + 1, 28))
            cash_data.append({
                "date": d.strftime("%Y-%m-%d"),
                "transaction_type": "INFLOW",
                "category": np.random.choice(["Sales Receipts", "Customer Advances", "Treasury Yield", "Export Rebates"]),
                "description": f"Operational customer cash inflow #{inv_id}",
                "amount": round(base_inflow / 12 * np.random.uniform(0.8, 1.2), 2)
            })
            inv_id += 1
            
        # Outflows
        for i in range(14):
            d = curr_m + timedelta(days=min(i * 2, 28))
            cat = "Capital Expenditure" if (is_neg and i in [2, 5]) else np.random.choice(["Vendor Payments", "Purchases", "Operating Expenses", "Payroll", "Logistics"])
            desc = "Heavy Machining & Automation Capex Overhaul" if cat == "Capital Expenditure" else f"Settlement payment #{inv_id}"
            cash_data.append({
                "date": d.strftime("%Y-%m-%d"),
                "transaction_type": "OUTFLOW",
                "category": cat,
                "description": desc,
                "amount": round(base_outflow / 14 * np.random.uniform(0.8, 1.2), 2)
            })
            inv_id += 1
            
        if curr_m.month == 12:
            curr_m = datetime(curr_m.year + 1, 1, 1)
        else:
            curr_m = datetime(curr_m.year, curr_m.month + 1, 1)
            
    pd.DataFrame(cash_data).to_csv(os.path.join(output_dir, "auxiliary_cash_flow.csv"), index=False)
    
    # 3. Production Capacity
    plants = [
        ("Plant Alpha (Pune)", 12500.0),
        ("Plant Beta (Chennai)", 9800.0),
        ("Plant Gamma (Gurugram)", 11200.0),
        ("Plant Delta (Kolkata)", 8400.0),
    ]
    prod_data = []
    curr_m = datetime(2025, 9, 1)
    while curr_m <= today:
        for p_name, cap in plants:
            for prod in ["Industrial Supply", "Machinery Components", "Power Systems"]:
                if "Alpha" in p_name:
                    util = np.random.uniform(91.0, 95.5)
                elif "Gamma" in p_name:
                    util = np.random.uniform(84.0, 90.0)
                elif "Beta" in p_name:
                    util = np.random.uniform(74.0, 82.0)
                else:
                    util = np.random.uniform(64.0, 72.0)
                    
                actual = round(cap * (util / 100.0) / 3, 1)
                planned = round(cap * np.random.uniform(0.88, 0.96) / 3, 1)
                util_pct = round((actual / (cap / 3)) * 100.0, 1)
                
                prod_data.append({
                    "date": curr_m.strftime("%Y-%m-%d"),
                    "plant": p_name,
                    "product": prod,
                    "capacity": round(cap / 3, 1),
                    "planned_quantity": planned,
                    "actual_quantity": actual,
                    "utilization_percentage": util_pct
                })
        if curr_m.month == 12:
            curr_m = datetime(curr_m.year + 1, 1, 1)
        else:
            curr_m = datetime(curr_m.year, curr_m.month + 1, 1)
            
    pd.DataFrame(prod_data).to_csv(os.path.join(output_dir, "auxiliary_production.csv"), index=False)

if __name__ == "__main__":
    preprocess_pipeline()
