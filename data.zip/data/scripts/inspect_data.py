import pandas as pd
import numpy as np

def inspect_dataco():
    raw_path = "data/raw/DataCoSupplyChainDataset.csv"
    print(f"Loading raw Kaggle dataset from: {raw_path}")
    df = pd.read_csv(raw_path, encoding="latin-1")
    print(f"Dataset Shape: {df.shape}")
    print("\n--- Column Names ---")
    for i, col in enumerate(df.columns):
        print(f"{i}: {col}")

    print("\n--- First 3 Rows Preview ---")
    print(df.head(3).to_dict(orient="records"))

    print("\n--- Market / Region values ---")
    if "Market" in df.columns:
        print("Market:", df["Market"].value_counts().to_dict())
    if "Order Region" in df.columns:
        print("Order Region:", df["Order Region"].value_counts().head(10).to_dict())
    if "Customer Segment" in df.columns:
        print("Customer Segment:", df["Customer Segment"].value_counts().to_dict())
    if "Order Status" in df.columns:
        print("Order Status:", df["Order Status"].value_counts().to_dict())
    if "Delivery Status" in df.columns:
        print("Delivery Status:", df["Delivery Status"].value_counts().to_dict())

    print("\n--- Financial Columns Sample ---")
    fin_cols = [c for c in df.columns if any(k in c.lower() for k in ["sale", "profit", "price", "cost", "total"])]
    print(fin_cols)
    print(df[fin_cols].describe().to_string())

if __name__ == "__main__":
    inspect_dataco()
