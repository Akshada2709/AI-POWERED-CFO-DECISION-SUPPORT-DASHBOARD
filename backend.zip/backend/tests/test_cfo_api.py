import pytest
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.db.database import SessionLocal
from backend.app.db.models import Sale, VendorPayable, CashTransaction

client = TestClient(app)

def test_health_endpoint():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

def test_dashboard_summary():
    response = client.get("/api/dashboard/summary")
    assert response.status_code == 200
    data = response.json()
    assert data["total_sales"] > 0
    assert data["total_profit"] > 0
    assert len(data["kpi_cards"]) >= 6
    # Verify profit margin formula
    expected_margin = round(data["total_profit"] / data["total_sales"] * 100.0, 2)
    assert abs(data["profit_margin"] - expected_margin) < 0.1

def test_sales_by_region():
    response = client.get("/api/sales/by-region")
    assert response.status_code == 200
    regions = response.json()
    reg_names = [r["region"] for r in regions]
    assert "North" in reg_names
    assert "South" in reg_names
    assert "East" in reg_names
    assert "West" in reg_names
    for r in regions:
        assert r["revenue"] > 0
        assert r["profit"] > 0
        # verify profit margin
        calc_margin = round(r["profit"] / r["revenue"] * 100.0, 2)
        assert abs(r["profit_margin"] - calc_margin) < 0.1

def test_sales_by_segment():
    response = client.get("/api/sales/by-segment")
    assert response.status_code == 200
    segments = response.json()
    seg_names = [s["segment"] for s in segments]
    assert any(s in seg_names for s in ["Enterprise", "Government", "Retail", "SME"])

def test_payables_and_overdue():
    response = client.get("/api/payables")
    assert response.status_code == 200
    payables = response.json()
    assert len(payables) > 0
    for p in payables:
        assert p["paid_amount"] <= p["invoice_amount"] + 0.01
        assert abs(p["outstanding_amount"] - (p["invoice_amount"] - p["paid_amount"])) < 0.1

def test_cash_flow_trend():
    response = client.get("/api/cash-flow/trend")
    assert response.status_code == 200
    trend = response.json()
    assert len(trend) >= 10
    for m in trend:
        calc_net = round(m["inflow"] - m["outflow"], 2)
        assert abs(m["net_cash_flow"] - calc_net) < 0.1

def test_production_capacity():
    response = client.get("/api/production")
    assert response.status_code == 200
    prods = response.json()
    assert len(prods) > 0
    for p in prods:
        assert p["capacity"] > 0
        assert p["actual"] > 0
        assert 0 <= p["utilization_percentage"] <= 120

def test_ai_query_sales_by_region():
    response = client.post("/api/ai/query", json={"prompt": "Show sales by region"})
    assert response.status_code == 200
    res = response.json()
    assert res["intent"] == "sales_by_region"
    assert res["visualization"]["type"] == "bar"
    assert len(res["data"]) > 0

def test_ai_query_profitable_segment():
    response = client.post("/api/ai/query", json={"prompt": "Which segment is most profitable?"})
    assert response.status_code == 200
    res = response.json()
    assert res["intent"] == "profit_by_segment"
    assert "profitable" in res["insight"].lower() or "profit" in res["insight"].lower()

def test_ai_query_overdue_payables():
    response = client.post("/api/ai/query", json={"prompt": "Show overdue vendor payments"})
    assert response.status_code == 200
    res = response.json()
    assert res["intent"] == "overdue_payables"
    assert res["visualization"]["type"] == "table"

def test_ai_query_capacity_feasibility():
    response = client.post("/api/ai/query", json={"prompt": "Can we fulfill pending orders with current production capacity?"})
    assert response.status_code == 200
    res = response.json()
    assert res["intent"] == "order_capacity_check"
    assert "YES" in res["message"] or "NO" in res["message"]

def test_ai_security_protection():
    response = client.post("/api/ai/query", json={"prompt": "DROP TABLE sales; SELECT * FROM users;"})
    assert response.status_code == 200
    res = response.json()
    assert res["intent"] == "security_violation"
    assert "prohibited" in res["message"].lower() or "security" in res["message"].lower()
