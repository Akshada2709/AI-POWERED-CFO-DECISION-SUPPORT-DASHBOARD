import pytest
from sqlalchemy.orm import Session
from backend.app.db.database import SessionLocal
from backend.app.db.models import Sale, VendorPayable, CashTransaction, Production, Order, Dispatch

def test_sales_consistency():
    db: Session = SessionLocal()
    try:
        sales = db.query(Sale).all()
        assert len(sales) > 0, "Sales table should have records"
        for s in sales:
            # check profit = revenue - cost within 0.05
            assert abs(s.profit - (s.revenue - s.cost)) < 0.05, f"Sale {s.id} profit inconsistent: {s.profit} vs {s.revenue - s.cost}"
            assert s.revenue >= 0, f"Sale {s.id} revenue cannot be negative"
            assert s.quantity > 0, f"Sale {s.id} quantity must be positive"
    finally:
        db.close()

def test_payables_consistency():
    db: Session = SessionLocal()
    try:
        payables = db.query(VendorPayable).all()
        assert len(payables) > 0, "Payables should have records"
        for p in payables:
            assert p.paid_amount <= p.invoice_amount + 0.01, f"Payable {p.id} paid amount exceeds invoice"
            assert abs(p.outstanding_amount - (p.invoice_amount - p.paid_amount)) < 0.05, f"Payable {p.id} outstanding inconsistent"
            if p.status == "Paid":
                assert p.outstanding_amount == 0
            elif p.status in ["Outstanding", "Overdue"]:
                assert p.outstanding_amount > 0
    finally:
        db.close()

def test_dispatch_order_consistency():
    db: Session = SessionLocal()
    try:
        dispatches = db.query(Dispatch).all()
        assert len(dispatches) > 0, "Dispatches should have records"
        for d in dispatches:
            order = db.query(Order).filter(Order.id == d.order_id).first()
            assert order is not None
            assert d.quantity <= order.quantity, f"Dispatch {d.id} qty exceeds order qty"
    finally:
        db.close()

def test_production_utilization_consistency():
    db: Session = SessionLocal()
    try:
        prods = db.query(Production).all()
        assert len(prods) > 0
        for p in prods:
            expected_util = round((p.actual_quantity / p.capacity) * 100.0, 1)
            assert abs(p.utilization_percentage - expected_util) < 0.2
    finally:
        db.close()
