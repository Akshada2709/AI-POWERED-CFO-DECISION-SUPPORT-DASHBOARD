import os
import random
from datetime import date, datetime, timedelta
import numpy as np
from sqlalchemy.orm import Session

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2]))

from backend.app.db.database import engine, Base, SessionLocal
from backend.app.db.models import (
    User, Region, Segment, Product, Plant, Vendor, Customer,
    Sale, Purchase, VendorPayable, CashTransaction, Production, Order, Dispatch
)

def seed_database():
    print("Dropping and recreating database tables...")
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)

    db: Session = SessionLocal()
    random.seed(42)
    np.random.seed(42)

    try:
        print("Seeding Master Data...")
        # 1. Users
        cfo_user = User(
            name="Aditya Verma",
            email="cfo@company.com",
            password_hash="$2b$12$e7kH6mG9Xl6D1z0Q0Q0Q0uKqJ9y3v5w6x7y8z9a0b1c2d3e4f5g6h", # dummy hash
            role="CFO"
        )
        db.add(cfo_user)

        # 2. Regions
        regions = ["North", "South", "East", "West"]
        for r in regions:
            db.add(Region(name=r))

        # 3. Segments
        segments = ["Government", "Enterprise", "Retail", "SME"]
        for s in segments:
            db.add(Segment(name=s))

        # 4. Products
        products_data = [
            ("Industrial Turbine Gen-4", "Heavy Machinery", 2500000.0, 1750000.0), # 30% margin
            ("Commercial Solar Inverter 500kW", "Clean Energy", 850000.0, 550000.0), # 35.3% margin
            ("Enterprise High-Density Server", "IT Infrastructure", 450000.0, 360000.0), # 20% margin
            ("Precision Hydraulic Valve", "Components", 75000.0, 48000.0), # 36% margin
            ("Modular Power Distribution Unit", "Electrical", 180000.0, 140000.0), # 22% margin
            ("Automated Conveyor Module", "Automation", 320000.0, 210000.0), # 34.4% margin
        ]
        product_objs = []
        for name, cat, price, cost in products_data:
            p = Product(product_name=name, category=cat, unit_price=price, unit_cost=cost)
            db.add(p)
            product_objs.append(p)

        # 5. Plants
        plants_data = [
            ("Plant Alpha (Pune)", "Pune, Maharashtra", 12000.0),
            ("Plant Beta (Chennai)", "Chennai, Tamil Nadu", 9500.0),
            ("Plant Gamma (Gurugram)", "Gurugram, Haryana", 11000.0),
            ("Plant Delta (Kolkata)", "Kolkata, West Bengal", 8000.0),
        ]
        for name, loc, cap in plants_data:
            db.add(Plant(plant_name=name, location=loc, production_capacity=cap))

        # 6. Vendors
        vendors_data = [
            ("Apex Industrial Supplies", "Raw Materials", "procurement@apexind.com"),
            ("Vertex Logistics & Freight", "Logistics", "billing@vertexlogistics.in"),
            ("SteelTech Infra Corp", "Steel & Alloys", "accounts@steeltechinfra.com"),
            ("Kavita Microelectronics", "Semiconductors", "finance@kavita-micro.in"),
            ("Bharat Power Grid Solutions", "Electricals", "support@bharatpowergrid.in"),
            ("Precision Tooling Works", "Machining", "contact@precisiontools.in"),
            ("National Energy Carriers", "Fuel & Utilities", "ops@nationalenergy.com"),
            ("Titanium Precision Components", "Hardware", "sales@titaniumcomponents.com"),
            ("Omni Cloud & IT Services", "Technology", "billing@omnicloud.in"),
            ("Delta Packaging Solutions", "Packaging", "info@deltapackaging.in"),
        ]
        for name, cat, contact in vendors_data:
            db.add(Vendor(vendor_name=name, category=cat, contact=contact))

        # 7. Customers
        customer_names = [
            ("Bharat Heavy Heavy Engineering", "North", "Government"),
            ("Indian Defense Logistics", "North", "Government"),
            ("Northern Infrastructure Corp", "North", "Enterprise"),
            ("Delhi Rail Transport Corp", "North", "Government"),
            ("Bangalore Tech Park Ltd", "South", "Enterprise"),
            ("Karnataka State Power Corp", "South", "Government"),
            ("Chennai Automotive Systems", "South", "Enterprise"),
            ("Deccan Retail Consortium", "South", "Retail"),
            ("Tata Global Industrial Hub", "East", "Enterprise"),
            ("Kolkata Municipal Utility", "East", "Government"),
            ("Eastern Heavy Forge", "East", "SME"),
            ("Bengal Trade Network", "East", "Retail"),
            ("Mumbai Port Logistics", "West", "Enterprise"),
            ("Gujarat Solar Energy Ltd", "West", "Enterprise"),
            ("Western Dynamic Retail", "West", "Retail"),
            ("Ahmedabad Precision SME Ltd", "West", "SME"),
        ]
        for name, reg, seg in customer_names:
            db.add(Customer(name=name, region=reg, segment=seg))

        db.commit()

        print("Generating 12 months of consistent transaction data...")
        # Today anchor date: 2026-08-31
        end_date = date(2026, 8, 31)
        start_date = date(2025, 9, 1)

        # 8. Sales Transactions
        # Region Profiles:
        # North: High volume, high revenue, lower margin (~16% margin because high discounts/costs)
        # South: High revenue, superior margin (~36%)
        # West: Good volume, balanced margin (~28%)
        # East: Moderate volume, solid margin (~31%)
        sales_records = []
        curr_date = start_date
        while curr_date <= end_date:
            # 4 to 8 sales transactions per day
            daily_txns = random.randint(3, 7)
            for _ in range(daily_txns):
                reg = random.choices(["North", "South", "West", "East"], weights=[35, 30, 20, 15])[0]
                seg = random.choices(["Enterprise", "Government", "Retail", "SME"], weights=[40, 25, 20, 15])[0]
                prod_idx = random.randint(0, len(products_data) - 1)
                p_name, _, p_price, base_cost = products_data[prod_idx]
                qty = random.randint(1, 8)
                
                # Region margin adjustments
                if reg == "North":
                    # High sales, high cost (low margin)
                    cost_factor = random.uniform(0.82, 0.88)
                elif reg == "South":
                    cost_factor = random.uniform(0.60, 0.68)
                elif reg == "West":
                    cost_factor = random.uniform(0.68, 0.76)
                else: # East
                    cost_factor = random.uniform(0.66, 0.74)

                revenue = round(p_price * qty, 2)
                cost = round(revenue * cost_factor, 2)
                profit = round(revenue - cost, 2)

                matching_cust = [c[0] for c in customer_names if c[1] == reg and c[2] == seg]
                c_name = random.choice(matching_cust) if matching_cust else f"{reg} Client"

                sale = Sale(
                    date=curr_date,
                    customer_name=c_name,
                    region=reg,
                    segment=seg,
                    product=p_name,
                    quantity=qty,
                    revenue=revenue,
                    cost=cost,
                    profit=profit
                )
                sales_records.append(sale)

            curr_date += timedelta(days=1)

        db.bulk_save_objects(sales_records)
        db.commit()
        print(f"Inserted {len(sales_records)} sales records.")

        # 9. Vendor Payables
        # Some are paid, partially paid, outstanding, and overdue!
        payables = []
        inv_counter = 1001
        for v_name, _, _ in vendors_data:
            # 6 to 10 invoices per vendor across the year
            num_inv = random.randint(6, 9)
            for _ in range(num_inv):
                inv_days_ago = random.randint(10, 360)
                inv_date = end_date - timedelta(days=inv_days_ago)
                terms = random.choice([30, 45, 60])
                due_date = inv_date + timedelta(days=terms)
                inv_amount = round(random.uniform(350000.0, 3200000.0), 2)

                if due_date < end_date:
                    # Due date passed
                    status_choice = random.choices(["Paid", "Partially Paid", "Overdue"], weights=[55, 20, 25])[0]
                    if status_choice == "Paid":
                        paid_amt = inv_amount
                        out_amt = 0.0
                        status = "Paid"
                    elif status_choice == "Partially Paid":
                        paid_amt = round(inv_amount * random.uniform(0.3, 0.7), 2)
                        out_amt = round(inv_amount - paid_amt, 2)
                        status = "Partially Paid"
                    else:
                        paid_amt = round(inv_amount * random.uniform(0.0, 0.2), 2)
                        out_amt = round(inv_amount - paid_amt, 2)
                        status = "Overdue"
                else:
                    # Future due date
                    status_choice = random.choices(["Outstanding", "Partially Paid", "Paid"], weights=[65, 25, 10])[0]
                    if status_choice == "Paid":
                        paid_amt = inv_amount
                        out_amt = 0.0
                        status = "Paid"
                    elif status_choice == "Partially Paid":
                        paid_amt = round(inv_amount * random.uniform(0.2, 0.5), 2)
                        out_amt = round(inv_amount - paid_amt, 2)
                        status = "Partially Paid"
                    else:
                        paid_amt = 0.0
                        out_amt = inv_amount
                        status = "Outstanding"

                vp = VendorPayable(
                    vendor=v_name,
                    invoice_number=f"INV-{inv_counter}",
                    invoice_date=inv_date,
                    due_date=due_date,
                    invoice_amount=inv_amount,
                    paid_amount=paid_amt,
                    outstanding_amount=out_amt,
                    status=status
                )
                payables.append(vp)
                inv_counter += 1

        db.bulk_save_objects(payables)
        db.commit()
        print(f"Inserted {len(payables)} vendor payables records.")

        # 10. Cash Transactions
        # Inflows (Sales Receipts, Customer Advances) & Outflows (Vendor Payments, Salaries, Capex, Utilities)
        # We ensure that in July 2026, cash flow was negative due to heavy capex and bulk vendor settlements!
        cash_txns = []
        curr_m = date(2025, 9, 1)
        while curr_m <= end_date:
            month_days = 30
            # Target monthly totals
            is_negative_month = (curr_m.year == 2026 and curr_m.month == 7) # July 2026 negative cash flow!
            if is_negative_month:
                target_inflow = 35000000.0  # 3.5 Cr
                target_outflow = 48500000.0 # 4.85 Cr -> Net -1.35 Cr
            else:
                target_inflow = random.uniform(42000000.0, 65000000.0)
                target_outflow = target_inflow * random.uniform(0.72, 0.90)

            # Generate ~15 inflow transactions
            inflow_cats = ["Sales Receipts", "Customer Advances", "Export Rebates", "Interest & Treasury"]
            for i in range(14):
                tx_date = curr_m + timedelta(days=min(i * 2 + 1, 28))
                amt = round(target_inflow / 14 * random.uniform(0.8, 1.2), 2)
                cash_txns.append(CashTransaction(
                    date=tx_date,
                    transaction_type="INFLOW",
                    category=random.choice(inflow_cats),
                    description=f"Operational receipt ref #{random.randint(10000, 99999)}",
                    amount=amt
                ))

            # Generate ~18 outflow transactions
            outflow_cats = ["Vendor Payments", "Purchases", "Operating Expenses", "Payroll & Compensation", "Logistics & Freight"]
            if is_negative_month:
                outflow_cats.append("Capital Expenditure")
            for i in range(16):
                tx_date = curr_m + timedelta(days=min(i * 2, 28))
                cat = "Capital Expenditure" if (is_negative_month and i in [3, 7]) else random.choice(outflow_cats)
                amt = round(target_outflow / 16 * random.uniform(0.7, 1.3), 2)
                desc = "Annual Production Line Machinery Expansion & Heavy Overhaul" if cat == "Capital Expenditure" else f"Settlement payment ref #{random.randint(10000, 99999)}"
                cash_txns.append(CashTransaction(
                    date=tx_date,
                    transaction_type="OUTFLOW",
                    category=cat,
                    description=desc,
                    amount=amt
                ))

            # Advance to next month
            if curr_m.month == 12:
                curr_m = date(curr_m.year + 1, 1, 1)
            else:
                curr_m = date(curr_m.year, curr_m.month + 1, 1)

        db.bulk_save_objects(cash_txns)
        db.commit()
        print(f"Inserted {len(cash_txns)} cash transaction records.")

        # 11. Production Records (Monthly or bi-weekly per plant)
        prod_records = []
        plants_list = ["Plant Alpha (Pune)", "Plant Beta (Chennai)", "Plant Gamma (Gurugram)", "Plant Delta (Kolkata)"]
        curr_m = date(2025, 9, 1)
        while curr_m <= end_date:
            for plant_name in plants_list:
                for p_name, _, _, _ in products_data[:4]:
                    # Base capacity
                    cap = 850.0 if "Alpha" in plant_name else (750.0 if "Gamma" in plant_name else 600.0)
                    # Alpha runs at ~92%, Beta ~78%, Gamma ~88%, Delta ~68%
                    if "Alpha" in plant_name:
                        util = random.uniform(89.0, 95.0)
                    elif "Gamma" in plant_name:
                        util = random.uniform(84.0, 91.0)
                    elif "Beta" in plant_name:
                        util = random.uniform(74.0, 82.0)
                    else:
                        util = random.uniform(62.0, 72.0)

                    actual = round(cap * (util / 100.0), 1)
                    planned = round(cap * random.uniform(0.85, 0.98), 1)
                    util_pct = round((actual / cap) * 100.0, 1)

                    prod_records.append(Production(
                        date=curr_m,
                        plant=plant_name,
                        product=p_name,
                        capacity=cap,
                        planned_quantity=planned,
                        actual_quantity=actual,
                        utilization_percentage=util_pct
                    ))

            if curr_m.month == 12:
                curr_m = date(curr_m.year + 1, 1, 1)
            else:
                curr_m = date(curr_m.year, curr_m.month + 1, 1)

        db.bulk_save_objects(prod_records)
        db.commit()
        print(f"Inserted {len(prod_records)} production records.")

        # 12. Orders and Dispatches
        # Generate orders across the last 6 months
        orders_list = []
        dispatches_list = []
        order_start = date(2026, 3, 1)
        curr_o_date = order_start
        o_id = 1
        while curr_o_date <= end_date:
            # 2 to 4 orders daily
            num_o = random.randint(2, 4)
            for _ in range(num_o):
                reg = random.choice(["North", "South", "East", "West"])
                prod_idx = random.randint(0, len(products_data) - 1)
                p_name, _, p_price, _ = products_data[prod_idx]
                qty = random.randint(5, 30)
                val = round(qty * p_price, 2)
                exp_date = curr_o_date + timedelta(days=random.randint(15, 60))

                # Order status
                if exp_date < end_date - timedelta(days=15):
                    status = random.choices(["Completed", "Cancelled", "In Progress"], weights=[80, 5, 15])[0]
                elif exp_date <= end_date:
                    status = random.choices(["Completed", "In Progress", "Pending"], weights=[50, 30, 20])[0]
                else:
                    status = random.choices(["Pending", "In Progress"], weights=[60, 40])[0]

                matching_cust = [c[0] for c in customer_names if c[1] == reg]
                c_name = random.choice(matching_cust) if matching_cust else f"{reg} Corporate Client"

                order_obj = Order(
                    order_date=curr_o_date,
                    customer_name=c_name,
                    region=reg,
                    product=p_name,
                    quantity=qty,
                    order_value=val,
                    status=status,
                    expected_delivery_date=exp_date
                )
                db.add(order_obj)
                db.flush() # obtain order_obj.id

                # Generate dispatch records for completed or in progress orders
                if status == "Completed":
                    d = Dispatch(
                        order_id=order_obj.id,
                        dispatch_date=curr_o_date + timedelta(days=random.randint(5, 20)),
                        quantity=qty,
                        status="Dispatched"
                    )
                    db.add(d)
                elif status == "In Progress":
                    disp_qty = random.randint(1, qty - 1) if qty > 1 else 0
                    if disp_qty > 0:
                        d = Dispatch(
                            order_id=order_obj.id,
                            dispatch_date=curr_o_date + timedelta(days=random.randint(3, 10)),
                            quantity=disp_qty,
                            status="Partially Dispatched"
                        )
                        db.add(d)
                elif status == "Pending":
                    # Pending dispatch
                    if random.random() < 0.2 and qty > 2:
                        d = Dispatch(
                            order_id=order_obj.id,
                            dispatch_date=curr_o_date + timedelta(days=2),
                            quantity=1,
                            status="Partially Dispatched"
                        )
                        db.add(d)

                o_id += 1

            curr_o_date += timedelta(days=1)

        db.commit()
        print(f"Inserted orders and dispatches successfully.")

        print("Database seeded and verified successfully!")

    except Exception as e:
        db.rollback()
        print(f"Error seeding database: {e}")
        raise e
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()
