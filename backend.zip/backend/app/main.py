from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.app.core.config import settings
from backend.app.api.routes import (
    dashboard, sales, profitability, payables,
    cash_flow, production, orders, dispatch, ai
)

app = FastAPI(
    title="AI-Powered CFO Decision Support System",
    description="Enterprise CFO Decision Support API combining Kaggle Supply Chain Data, Financial Aggregations, and Natural Language AI.",
    version="1.0.0"
)

# Enable CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routers
app.include_router(dashboard.router)
app.include_router(sales.router)
app.include_router(profitability.router)
app.include_router(payables.router)
app.include_router(cash_flow.router)
app.include_router(production.router)
app.include_router(orders.router)
app.include_router(dispatch.router)
app.include_router(ai.router)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "service": "CFO Decision Support API",
        "environment": settings.ENVIRONMENT
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host=settings.HOST, port=settings.PORT, reload=True)
