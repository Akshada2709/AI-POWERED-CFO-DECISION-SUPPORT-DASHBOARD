from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import ProductionPlantItem
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/production", tags=["Production"])

@router.get("", response_model=List[ProductionPlantItem])
def get_production_capacity(db: Session = Depends(get_db)):
    """Retrieve plant-wise capacity, actual production, and utilization %"""
    return AnalyticsService.get_production_capacity(db)
