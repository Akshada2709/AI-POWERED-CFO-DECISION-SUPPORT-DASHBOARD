from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import DispatchStatusSummary
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/dispatch", tags=["Dispatch"])

@router.get("/summary", response_model=List[DispatchStatusSummary])
def get_dispatch_summary(db: Session = Depends(get_db)):
    """Retrieve dispatch operational status summary"""
    return AnalyticsService.get_dispatch_summary(db)
