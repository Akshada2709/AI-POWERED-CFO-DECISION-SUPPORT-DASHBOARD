from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import OrderStatusSummary
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/orders", tags=["Orders"])

@router.get("/summary", response_model=List[OrderStatusSummary])
def get_orders_summary(db: Session = Depends(get_db)):
    """Retrieve orders grouped by fulfillment status"""
    return AnalyticsService.get_orders_summary(db)
