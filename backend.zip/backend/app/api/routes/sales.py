from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import RegionSalesItem, SegmentSalesItem
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/sales", tags=["Sales"])

@router.get("/by-region", response_model=List[RegionSalesItem])
def get_sales_by_region(db: Session = Depends(get_db)):
    """Retrieve sales and profit grouped by North, South, East, and West"""
    return AnalyticsService.get_sales_by_region(db)

@router.get("/by-segment", response_model=List[SegmentSalesItem])
def get_sales_by_segment(db: Session = Depends(get_db)):
    """Retrieve sales and profit grouped by Government, Enterprise, Retail, and SME"""
    return AnalyticsService.get_sales_by_segment(db)
