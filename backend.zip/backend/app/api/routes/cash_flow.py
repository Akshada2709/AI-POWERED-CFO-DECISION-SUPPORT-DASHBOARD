from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import MonthlyCashFlowItem
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/cash-flow", tags=["Cash Flow"])

@router.get("/trend", response_model=List[MonthlyCashFlowItem])
def get_cash_flow_trend(db: Session = Depends(get_db)):
    """Retrieve 12-month cash inflows, outflows, and net cash flow trajectory"""
    return AnalyticsService.get_cash_flow_trend(db)
