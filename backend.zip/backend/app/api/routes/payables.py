from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import PayableItem
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/payables", tags=["Payables"])

@router.get("", response_model=List[PayableItem])
def get_payables(status: Optional[str] = Query(None), db: Session = Depends(get_db)):
    """Retrieve vendor payables with status filtering"""
    return AnalyticsService.get_payables(db, status=status)

@router.get("/summary")
def get_payables_summary(db: Session = Depends(get_db)):
    """Retrieve payables overview statistics"""
    all_p = AnalyticsService.get_payables(db)
    tot_out = sum(p.outstanding_amount for p in all_p)
    tot_overdue = sum(p.outstanding_amount for p in all_p if p.status == "Overdue")
    return {
        "total_invoices": len(all_p),
        "total_outstanding": tot_out,
        "total_overdue": tot_overdue,
        "overdue_count": sum(1 for p in all_p if p.status == "Overdue")
    }
