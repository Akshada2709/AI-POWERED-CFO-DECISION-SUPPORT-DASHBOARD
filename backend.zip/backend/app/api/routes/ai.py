from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import AIQueryRequest, AIQueryResponse
from backend.app.services.ai_service import AIService

router = APIRouter(prefix="/api/ai", tags=["AI CFO Assistant"])

@router.post("/query", response_model=AIQueryResponse)
def process_cfo_query(request: AIQueryRequest, db: Session = Depends(get_db)):
    """
    Process natural-language CFO business queries into structured intent,
    execute validated database query, and return structured visualizations & insights.
    """
    return AIService.process_query(request.prompt, db)
