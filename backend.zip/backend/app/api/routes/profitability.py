from typing import List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from backend.app.db.database import get_db
from backend.app.schemas.cfo_schemas import RegionSalesItem, SegmentSalesItem
from backend.app.services.analytics_service import AnalyticsService

router = APIRouter(prefix="/api/profitability", tags=["Profitability"])

@router.get("/by-region", response_model=List[RegionSalesItem])
def get_profitability_by_region(db: Session = Depends(get_db)):
    """Retrieve regional profitability metrics and operating margin %"""
    return AnalyticsService.get_sales_by_region(db)

@router.get("/by-segment", response_model=List[SegmentSalesItem])
def get_profitability_by_segment(db: Session = Depends(get_db)):
    """Retrieve segment-wise profit metrics and margins"""
    return AnalyticsService.get_sales_by_segment(db)
