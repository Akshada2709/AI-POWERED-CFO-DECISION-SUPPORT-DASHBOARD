import os
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    PROJECT_NAME: str = "AI-Powered CFO Decision Support Dashboard"
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./cfo_dashboard.db")
    HOST: str = os.getenv("HOST", "127.0.0.1")
    PORT: int = int(os.getenv("PORT", "8000"))
    FRONTEND_URL: str = os.getenv("FRONTEND_URL", "http://localhost:3000")
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
    LLM_MODEL: str = os.getenv("LLM_MODEL", "gemini-1.5-pro")
    SECRET_KEY: str = os.getenv("SECRET_KEY", "cfo-secret-key")
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")

    model_config = {"case_sensitive": True}

settings = Settings()
