from datetime import datetime, date
from sqlalchemy import Column, Integer, String, Float, Date, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from backend.app.db.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(120), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(50), default="CFO")
    created_at = Column(DateTime, default=datetime.utcnow)

class Region(Base):
    __tablename__ = "regions"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)

class Segment(Base):
    __tablename__ = "segments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50), unique=True, nullable=False)

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(100), unique=True, nullable=False)
    category = Column(String(50), nullable=False)
    unit_price = Column(Float, nullable=False)
    unit_cost = Column(Float, nullable=False)

class Plant(Base):
    __tablename__ = "plants"

    id = Column(Integer, primary_key=True, index=True)
    plant_name = Column(String(100), unique=True, nullable=False)
    location = Column(String(100), nullable=False)
    production_capacity = Column(Float, nullable=False)

class Vendor(Base):
    __tablename__ = "vendors"

    id = Column(Integer, primary_key=True, index=True)
    vendor_name = Column(String(120), unique=True, nullable=False)
    category = Column(String(80), nullable=False)
    contact = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Customer(Base):
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    region = Column(String(50), index=True, nullable=False)
    segment = Column(String(50), index=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Sale(Base):
    __tablename__ = "sales"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, index=True, nullable=False)
    customer_name = Column(String(120), nullable=True)
    region = Column(String(50), index=True, nullable=False)
    segment = Column(String(50), index=True, nullable=False)
    product = Column(String(100), index=True, nullable=False)
    quantity = Column(Integer, nullable=False)
    revenue = Column(Float, nullable=False)
    cost = Column(Float, nullable=False)
    profit = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Purchase(Base):
    __tablename__ = "purchases"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, index=True, nullable=False)
    vendor = Column(String(120), index=True, nullable=False)
    product = Column(String(100), nullable=True)
    quantity = Column(Integer, default=1)
    purchase_amount = Column(Float, nullable=False)
    status = Column(String(50), default="Completed")

class VendorPayable(Base):
    __tablename__ = "vendor_payables"

    id = Column(Integer, primary_key=True, index=True)
    vendor = Column(String(120), index=True, nullable=False)
    invoice_number = Column(String(50), unique=True, index=True, nullable=False)
    invoice_date = Column(Date, index=True, nullable=False)
    due_date = Column(Date, index=True, nullable=False)
    invoice_amount = Column(Float, nullable=False)
    paid_amount = Column(Float, nullable=False)
    outstanding_amount = Column(Float, nullable=False)
    status = Column(String(50), index=True, nullable=False)  # Paid, Partially Paid, Outstanding, Overdue

class CashTransaction(Base):
    __tablename__ = "cash_transactions"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, index=True, nullable=False)
    transaction_type = Column(String(20), index=True, nullable=False)  # INFLOW / OUTFLOW
    category = Column(String(80), index=True, nullable=False)
    description = Column(String(255), nullable=True)
    amount = Column(Float, nullable=False)

class Production(Base):
    __tablename__ = "production"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, index=True, nullable=False)
    plant = Column(String(100), index=True, nullable=False)
    product = Column(String(100), index=True, nullable=False)
    capacity = Column(Float, nullable=False)
    planned_quantity = Column(Float, nullable=False)
    actual_quantity = Column(Float, nullable=False)
    utilization_percentage = Column(Float, nullable=False)

class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True, index=True)
    order_date = Column(Date, index=True, nullable=False)
    customer_name = Column(String(120), nullable=True)
    region = Column(String(50), index=True, nullable=False)
    product = Column(String(100), index=True, nullable=False)
    quantity = Column(Integer, nullable=False)
    order_value = Column(Float, nullable=False)
    status = Column(String(50), index=True, nullable=False)  # Pending, In Progress, Completed, Cancelled
    expected_delivery_date = Column(Date, nullable=False)

    dispatches = relationship("Dispatch", back_populates="order", cascade="all, delete-orphan")

class Dispatch(Base):
    __tablename__ = "dispatches"

    id = Column(Integer, primary_key=True, index=True)
    order_id = Column(Integer, ForeignKey("orders.id"), nullable=False)
    dispatch_date = Column(Date, index=True, nullable=False)
    quantity = Column(Integer, nullable=False)
    status = Column(String(50), nullable=False)  # Pending, Partially Dispatched, Dispatched

    order = relationship("Order", back_populates="dispatches")
