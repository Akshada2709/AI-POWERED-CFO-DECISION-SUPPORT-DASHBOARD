from typing import List, Optional, Any, Dict
from pydantic import BaseModel, Field

class KPICard(BaseModel):
    title: str
    value: float
    formatted_value: str
    subtitle: Optional[str] = None
    trend_pct: Optional[float] = None
    status: Optional[str] = "neutral"  # positive, negative, warning, neutral

class DashboardSummaryResponse(BaseModel):
    total_sales: float
    total_profit: float
    profit_margin: float
    net_cash_flow: float
    outstanding_payables: float
    overdue_payables: float
    pending_orders: int
    production_utilization: float
    kpi_cards: List[KPICard]
    alerts: List[Dict[str, Any]]

class RegionSalesItem(BaseModel):
    region: str
    revenue: float
    profit: float
    profit_margin: float
    orders_count: int

class SegmentSalesItem(BaseModel):
    segment: str
    revenue: float
    profit: float
    profit_margin: float
    orders_count: int

class MonthlyCashFlowItem(BaseModel):
    month: str
    inflow: float
    outflow: float
    net_cash_flow: float

class PayableItem(BaseModel):
    id: int
    vendor: str
    invoice_number: str
    invoice_date: str
    due_date: str
    invoice_amount: float
    paid_amount: float
    outstanding_amount: float
    status: str

class ProductionPlantItem(BaseModel):
    plant: str
    capacity: float
    planned: float
    actual: float
    utilization_percentage: float

class OrderStatusSummary(BaseModel):
    status: str
    count: int
    total_value: float

class DispatchStatusSummary(BaseModel):
    status: str
    count: int
    total_quantity: int

# AI Request & Response Schemas
class AIQueryRequest(BaseModel):
    prompt: str

class AIVisualization(BaseModel):
    type: str  # "bar", "line", "donut", "table", "kpi", "alert"
    x_axis: Optional[str] = None
    y_axis: Optional[str] = None
    title: Optional[str] = None
    series_name: Optional[str] = None

class AIQueryResponse(BaseModel):
    intent: str
    data: Any
    visualization: AIVisualization
    message: str
    insight: str
    details: Optional[Dict[str, Any]] = None
    suggested_followups: List[str] = []
