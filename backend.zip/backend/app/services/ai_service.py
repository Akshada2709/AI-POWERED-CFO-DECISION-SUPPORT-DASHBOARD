import re
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from backend.app.schemas.cfo_schemas import AIQueryResponse, AIVisualization
from backend.app.services.analytics_service import AnalyticsService, format_inr
from backend.app.core.config import settings

MALICIOUS_PATTERNS = [
    r"drop\s+table", r"delete\s+from", r"truncate", r"insert\s+into",
    r"update\s+\w+\s+set", r"password", r"secret", r"credentials",
    r"union\s+select", r"exec\(", r"eval\("
]

class AIService:
    @staticmethod
    def classify_intent(prompt: str) -> str:
        """
        Classifies user prompt into a structured intent.
        Uses deterministic keyword/semantic parsing with fallback.
        """
        p = prompt.lower().strip()

        # Malicious check
        for pattern in MALICIOUS_PATTERNS:
            if re.search(pattern, p):
                return "security_violation"

        # 1. Cross-module: high sales low profit
        if any(k in p for k in ["high sales but low profit", "high sales low profit", "low margin region", "regional profitability"]):
            return "regional_profitability"

        # 2. Cross-module: order fulfillment & production capacity
        if any(k in p for k in [
            "fulfill pending orders", "fulfill all pending orders", "enough capacity",
            "capacity check", "fulfill orders", "production capacity enough"
        ]):
            return "order_capacity_check"

        # 3. Overdue payables / vendor liabilities
        if any(k in p for k in ["overdue", "due payment", "late payment", "unpaid vendor", "vendor burden"]):
            return "overdue_payables"

        # 4. Profit by segment / Most profitable segment
        if any(k in p for k in ["profitable segment", "segment profitability", "highest profit segment", "profit by segment", "most profitable"]):
            return "profit_by_segment"

        # 5. Sales by region / Regional sales
        if any(k in p for k in ["sales by region", "regional sales", "region sales", "sales in north", "north region sales", "sales for north"]):
            return "sales_by_region"

        # 6. Sales by segment
        if any(k in p for k in ["sales by segment", "segment sales", "revenue by segment"]):
            return "sales_by_segment"

        # 7. Cash flow negative explanation
        if any(k in p for k in ["why was cash flow negative", "negative cash flow", "cash flow down", "cash deficit"]):
            return "cash_flow_explanation"

        # 8. Cash flow summary / trend
        if any(k in p for k in ["cash flow", "net cash", "cash inflow", "cash outflow"]):
            return "cash_flow_summary"

        # 9. Production capacity / Plant utilization
        if any(k in p for k in ["production", "capacity", "utilization", "plant"]):
            return "production_capacity"

        # 10. Pending orders
        if any(k in p for k in ["pending order", "orders pending", "order status", "orders"]):
            return "pending_orders"

        # 11. Dispatch status
        if any(k in p for k in ["dispatch", "shipping status", "deliveries"]):
            return "dispatch_summary"

        return "unknown"

    @staticmethod
    def process_query(prompt: str, db: Session) -> AIQueryResponse:
        intent = AIService.classify_intent(prompt)

        if intent == "security_violation":
            return AIQueryResponse(
                intent="security_violation",
                data=[],
                visualization=AIVisualization(type="alert", title="Security Alert"),
                message="Security Policy Notice: Arbitrary execution, schema alteration, and credential extraction queries are strictly prohibited.",
                insight="The AI CFO Assistant operates strictly within authorized, validated financial analytical bounds.",
                suggested_followups=["Show sales by region", "Which segment is most profitable?"]
            )

        if intent == "sales_by_region":
            data = AnalyticsService.get_sales_by_region(db)
            top_r = data[0] if data else None
            top_text = f"{top_r.region} is the leading regional contributor with {format_inr(top_r.revenue)} ({top_r.profit_margin}% margin)." if top_r else ""
            return AIQueryResponse(
                intent="sales_by_region",
                data=[d.model_dump() for d in data],
                visualization=AIVisualization(
                    type="bar",
                    x_axis="region",
                    y_axis="revenue",
                    title="Revenue & Profit by Region",
                    series_name="Revenue (INR)"
                ),
                message="Here is the regional sales breakdown across North, South, East, and West.",
                insight=f"{top_text} Total regional revenue encompasses 15,000 Kaggle Supply Chain transactions.",
                suggested_followups=[
                    "Which regions have high sales but low profit?",
                    "Which segment is most profitable?",
                    "Can we fulfill pending orders with current production capacity?"
                ]
            )

        elif intent == "profit_by_segment":
            data = AnalyticsService.get_sales_by_segment(db)
            top_s = data[0] if data else None
            insight_text = f"{top_s.segment} is our most profitable business segment, generating {format_inr(top_s.profit)} in net profit with a margin of {top_s.profit_margin}%." if top_s else ""
            return AIQueryResponse(
                intent="profit_by_segment",
                data=[d.model_dump() for d in data],
                visualization=AIVisualization(
                    type="bar",
                    x_axis="segment",
                    y_axis="profit",
                    title="Segment Profitability & Operating Margin",
                    series_name="Gross Profit (INR)"
                ),
                message="Segment profitability analysis calculated from real order items and cost structures.",
                insight=insight_text,
                suggested_followups=[
                    "Show sales by region",
                    "Which regions have high sales but low profit?",
                    "Show overdue vendor payments"
                ]
            )

        elif intent == "overdue_payables":
            overdue_list = AnalyticsService.get_payables(db, status="Overdue")
            total_overdue = sum(p.outstanding_amount for p in overdue_list)
            top_vendor = overdue_list[0].vendor if overdue_list else "None"
            return AIQueryResponse(
                intent="overdue_payables",
                data=[p.model_dump() for p in overdue_list],
                visualization=AIVisualization(
                    type="table",
                    title="Overdue Vendor Payables Register"
                ),
                message=f"Identified {len(overdue_list)} overdue vendor invoices totaling {format_inr(total_overdue)}.",
                insight=f"Primary overdue concentration resides with {top_vendor}. Early vendor settlement prioritization is recommended to safeguard supply chain lead times.",
                details={"total_overdue": total_overdue, "count": len(overdue_list)},
                suggested_followups=[
                    "Why was cash flow negative last month?",
                    "What is our net cash flow?",
                    "Can we fulfill pending orders with current production capacity?"
                ]
            )

        elif intent == "order_capacity_check":
            res = AnalyticsService.check_order_capacity_feasibility(db)
            status_text = "YES — Available plant capacity is SUFFICIENT." if res["is_fulfillable"] else "NO — Production capacity is CONSTRAINED."
            insight_text = (
                f"We have {res['pending_order_quantity']:,} pending order units against {res['available_spare_capacity']:,.0f} units of spare capacity. "
                + (f"A comfortable surplus of {res['difference_units']:,.0f} units exists." if res["is_fulfillable"] else f"A shortage of {res['difference_units']:,.0f} units requires plant overtime scheduling.")
            )
            return AIQueryResponse(
                intent="order_capacity_check",
                data=res,
                visualization=AIVisualization(
                    type="kpi",
                    title="Order Fulfillment Capacity Assessment"
                ),
                message=status_text,
                insight=insight_text,
                details=res,
                suggested_followups=[
                    "Show production capacity",
                    "How many orders are pending?",
                    "Show overdue vendor payments"
                ]
            )

        elif intent == "regional_profitability":
            findings = AnalyticsService.get_high_sales_low_profit_regions(db)
            flagged = [f["region"] for f in findings if f["is_high_sales_low_margin"]]
            flagged_str = ", ".join(flagged) if flagged else "None"
            return AIQueryResponse(
                intent="regional_profitability",
                data=findings,
                visualization=AIVisualization(
                    type="bar",
                    x_axis="region",
                    y_axis="profit_margin",
                    title="Regional Sales vs Profit Margin Analysis"
                ),
                message=f"Regional efficiency review: {flagged_str} flagged for high transaction revenue combined with below-average profit margins.",
                insight=f"Regions like {flagged_str} suffer margin dilution due to heavy volume discounts and elevated logistics costs.",
                suggested_followups=[
                    "Show sales by region",
                    "Which segment is most profitable?",
                    "Show overdue vendor payments"
                ]
            )

        elif intent == "cash_flow_explanation":
            trend = AnalyticsService.get_cash_flow_trend(db)
            # Find negative month
            neg_months = [m for m in trend if m.net_cash_flow < 0]
            neg_desc = f"In {neg_months[0].month}, net cash flow was {format_inr(neg_months[0].net_cash_flow)}." if neg_months else "All tracked months maintained positive net operating cash."
            return AIQueryResponse(
                intent="cash_flow_explanation",
                data=[m.model_dump() for m in trend],
                visualization=AIVisualization(
                    type="line",
                    x_axis="month",
                    y_axis="net_cash_flow",
                    title="Monthly Net Cash Flow Trajectory"
                ),
                message="Cash Flow Variance Breakdown:",
                insight=f"{neg_desc} The deficit was primarily driven by strategic Capital Expenditure (machinery & automation overhaul) combined with quarterly vendor settlements.",
                suggested_followups=[
                    "Show overdue vendor payments",
                    "Which segment is most profitable?",
                    "Can we fulfill pending orders with current production capacity?"
                ]
            )

        elif intent == "cash_flow_summary":
            trend = AnalyticsService.get_cash_flow_trend(db)
            tot_inf = sum(t.inflow for t in trend)
            tot_outf = sum(t.outflow for t in trend)
            net = tot_inf - tot_outf
            return AIQueryResponse(
                intent="cash_flow_summary",
                data=[m.model_dump() for m in trend],
                visualization=AIVisualization(
                    type="line",
                    x_axis="month",
                    title="Cash Inflow vs Outflow Trend"
                ),
                message=f"Total Cumulative Inflows: {format_inr(tot_inf)} | Total Outflows: {format_inr(tot_outf)} | Net: {format_inr(net)}.",
                insight="Operational cash flows remain resilient with customer receivables comfortably financing current obligations.",
                suggested_followups=[
                    "Why was cash flow negative last month?",
                    "Show overdue vendor payments"
                ]
            )

        elif intent == "production_capacity":
            plants = AnalyticsService.get_production_capacity(db)
            top_plant = plants[0] if plants else None
            return AIQueryResponse(
                intent="production_capacity",
                data=[p.model_dump() for p in plants],
                visualization=AIVisualization(
                    type="bar",
                    x_axis="plant",
                    y_axis="utilization_percentage",
                    title="Plant Production Capacity & Utilization %"
                ),
                message="Manufacturing Plants Utilization Overview",
                insight=f"{top_plant.plant if top_plant else 'Plant Alpha'} exhibits the highest utilization at {top_plant.utilization_percentage if top_plant else 92}%.",
                suggested_followups=[
                    "Can we fulfill pending orders with current production capacity?",
                    "How many orders are pending?"
                ]
            )

        elif intent == "pending_orders":
            orders_summary = AnalyticsService.get_orders_summary(db)
            return AIQueryResponse(
                intent="pending_orders",
                data=[o.model_dump() for o in orders_summary],
                visualization=AIVisualization(
                    type="donut",
                    title="Orders Breakdown by Operational Status"
                ),
                message="Current order distribution across fulfillment stages.",
                insight="Orders in 'Pending' and 'In Progress' states are monitored against plant capacity and delivery schedules.",
                suggested_followups=[
                    "Can we fulfill pending orders with current production capacity?",
                    "What is the dispatch status?"
                ]
            )

        elif intent == "dispatch_summary":
            disp_summary = AnalyticsService.get_dispatch_summary(db)
            return AIQueryResponse(
                intent="dispatch_summary",
                data=[d.model_dump() for d in disp_summary],
                visualization=AIVisualization(
                    type="bar",
                    title="Dispatch & Shipping Fulfillment Status"
                ),
                message="Operational shipping summary derived from DataCo delivery records.",
                insight="Completed shipments reflect on-time delivery adherence across standard and expedited freight modes.",
                suggested_followups=[
                    "Show sales by region",
                    "Which segment is most profitable?"
                ]
            )

        # Fallback for unrecognized intent
        return AIQueryResponse(
            intent="unknown",
            data=[],
            visualization=AIVisualization(type="kpi", title="CFO Query Assistant"),
            message="I couldn't confidently interpret that specific query. Please try asking about sales, profitability, vendor payables, cash flow, production capacity, orders, or dispatches.",
            insight="Try one of the suggested CFO business queries below to see instant data-backed intelligence.",
            suggested_followups=[
                "Show sales by region",
                "Which segment is most profitable?",
                "Show overdue vendor payments",
                "Can we fulfill pending orders with current production capacity?",
                "Which regions have high sales but low profit?",
                "Why was cash flow negative last month?"
            ]
        )
