# Architecture Specification

## AI-Powered CFO Decision Support System

### 1. High-Level Flow
```
Kaggle DataCo Supply Chain Dataset (180,519 records)
                     ↓
Python / Pandas Data Ingestion & Preprocessing Pipeline
   - Missing value imputation & deduplication
   - Four-region mapping (North, South, East, West)
   - Segment standardization (Government, Enterprise, Retail, SME)
   - Feature engineering (profit, margin, delivery delays)
                     ↓
Cleaned Storage: PostgreSQL / Relational Database (15,000 active sales rows)
                     ↓
FastAPI Backend Layer (RESTful API & Service Architecture)
   - Pydantic v2 Request/Response Validation
   - Parameterized Aggregations & Query Builder
   - AnalyticsService & Deterministic Intent Engine
                     ↓
Next.js 16 + TypeScript + Tailwind CSS Frontend
   - Apache ECharts Interactive Data Visualizations
   - Executive Financial KPI Summary Cards
   - Natural Language AI Assistant Command Bar
```

### 2. Academic / Viva Conceptual Pipeline
1. **Data Collection & Ingestion**: Kaggle DataCo Smart Supply Chain Dataset.
2. **Data Profiling & EDA**: Distribution analysis, missing value auditing, and schema mapping.
3. **Data Cleaning**: Cleaning nulls, deduplicating order items, converting string timestamps to native ISO dates.
4. **Feature Engineering**: Deriving operating margin `(profit / revenue * 100)`, shipping variances, regional classifications.
5. **Data Storage & Modeling**: Relational schema separating Sales, Orders, Dispatches, Vendor Payables, Cash Transactions, and Production.
6. **Analytical Serving**: FastAPI service layer calculating real-time aggregated metrics with zero mocked or static numbers.
7. **AI Decision Support**: Structured natural-language query processing without allowing arbitrary SQL injection.
