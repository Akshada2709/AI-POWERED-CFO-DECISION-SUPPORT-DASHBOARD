# API Reference

### Base URL: `http://127.0.0.1:8000`

#### 1. System Health
- **`GET /api/health`**: Returns service health status.

#### 2. CFO Dashboard Summary
- **`GET /api/dashboard/summary`**: Consolidated executive overview returning top-level KPIs (Total Sales, Total Profit, Profit Margin, Net Cash Flow, Vendor Payables, Overdue Payables, Pending Orders, Capacity Utilization), structured KPI cards, and deterministic alerts.

#### 3. Sales Analytics
- **`GET /api/sales/by-region`**: Aggregated sales, profits, profit margins, and order counts grouped by `North`, `South`, `East`, and `West`.
- **`GET /api/sales/by-segment`**: Aggregated metrics grouped by `Government`, `Enterprise`, `Retail`, and `SME`.

#### 4. Profitability
- **`GET /api/profitability/by-region`**: Regional margins and gross profit.
- **`GET /api/profitability/by-segment`**: Segment-wise margin breakdown.

#### 5. Vendor Payables
- **`GET /api/payables`**: List of vendor invoices with optional query parameter `status` (`Overdue`, `Outstanding`, `Partially Paid`, `Paid`).
- **`GET /api/payables/summary`**: Invoice totals and overdue liabilities.

#### 6. Cash Flow
- **`GET /api/cash-flow/trend`**: Monthly cash inflows, outflows, and net cash flow trajectory.

#### 7. Operations & Production
- **`GET /api/production`**: Manufacturing plants capacity, actual output, and utilization percentage.
- **`GET /api/orders/summary`**: Orders grouped by status (`Completed`, `In Progress`, `Pending`).
- **`GET /api/dispatch/summary`**: Dispatches grouped by fulfillment state.

#### 8. AI Assistant
- **`POST /api/ai/query`**:
  - Request body: `{"prompt": "Show sales by region"}`
  - Returns: `AIQueryResponse` with structured intent, data, ECharts-compatible visualization spec, key insight, and suggested follow-up queries.
