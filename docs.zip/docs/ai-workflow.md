# AI Assistant Workflow & Intent Architecture

## 1. Zero Direct SQL Execution Policy
To protect enterprise data integrity and eliminate SQL injection, prompt injection, and database alteration attacks, the AI system does **NOT** generate or execute raw SQL strings.

The pipeline operates as follows:
```
User Natural Language Prompt
              ↓
Intent Classifier (LLM or Deterministic Fallback Engine)
              ↓
Structured Intent Token + Validated Parameters
              ↓
Backend Analytical Query Method (SQLAlchemy ORM)
              ↓
Safe Parameterized Database Aggregation
              ↓
Business Mathematical Computation (Margins, Differences, Ratios)
              ↓
Structured Response (Chart Data + Narrative Insight + Follow-up Prompts)
```

## 2. Core Supported Intent Matrix
| Intent | Example Prompt | Analysis Type | Output Visualization |
|---|---|---|---|
| `sales_by_region` | "Show sales by region." | Single-Module | Bar Chart (North, South, East, West) |
| `profit_by_segment` | "Which segment is most profitable?" | Single-Module | Bar Chart (Government, Enterprise, Retail, SME) |
| `overdue_payables` | "Show overdue vendor payments." | Single-Module | Filtered Table with Overdue Highlights |
| `order_capacity_check` | "Can we fulfill pending orders with current production capacity?" | **Cross-Module (Orders + Production)** | Feasibility Assessment Cards |
| `regional_profitability` | "Which regions have high sales but low profit?" | **Cross-Module (Sales + Margins)** | Efficiency Review Bar Chart |
| `cash_flow_explanation` | "Why was cash flow negative last month?" | Single-Module | Net Cash Variance Line Chart |
| `cash_flow_summary` | "What is our net cash flow?" | Single-Module | Inflow vs Outflow Trajectory |
| `production_capacity` | "What is our production capacity?" | Single-Module | Plant-wise Horizontal Utilization Bar |
| `pending_orders` | "How many orders are pending?" | Single-Module | Order Distribution Status Breakdown |
| `dispatch_summary` | "What is the dispatch status?" | Single-Module | Shipment Fulfillment Status |

## 3. Fallback Intent Engine
When no external LLM API key (`LLM_API_KEY`) is configured, the application uses an intelligent regex-driven keyword matcher. This guarantees 100% offline demonstration readiness without runtime failures or external network dependencies.
